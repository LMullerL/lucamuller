# Programação de Funcionalidades


Nesta seção são apresentadas as telas desenvolvidas para cada uma das funcionalidades do projeto, assim como a URL e orientações de acesso.


# Visualização das Postagens (RF-001)

A tela principal do site exibe as notícias postadas mais recentemente.

> **Links Úteis**:
>
> - [Trabalhando com HTML5 Local Storage e JSON](https://www.devmedia.com.br/trabalhando-com-html5-local-storage-e-json/29045)
> - [JSON Tutorial](https://www.w3resource.com/JSON)
> - [JSON Data Set Sample](https://opensource.adobe.com/Spry/samples/data_region/JSONDataSetSample.html)
> - [JSON - Introduction (W3Schools)](https://www.w3schools.com/js/js_json_intro.asp)
> - [JSON Tutorial (TutorialsPoint)](https://www.tutorialspoint.com/json/index.htm)
