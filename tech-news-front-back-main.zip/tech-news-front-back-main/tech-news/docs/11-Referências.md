# Referências

> - (https://hotmart.com/pt-br/blog/publico-alvo)
> - https://resultadosdigitais.com.br/marketing/persona-o-que-e/
> - https://negociossc.com.br/
> - https://rockcontent.com/br/blog/personas/
> - https://www.atlassian.com/br/agile/project-management/user-stories
> - https://codificar.com.br/requisitos-funcionais-nao-funcionais/

> **Links Úteis**:
> - [Formato ABNT](https://www.normastecnicas.com/abnt/trabalhos-academicos/referencias/)
> - [Referências Bibliográficas da ABNT](https://comunidade.rockcontent.com/referencia-bibliografica-abnt/)
